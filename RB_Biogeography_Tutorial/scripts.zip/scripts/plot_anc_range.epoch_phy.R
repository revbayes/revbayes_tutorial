out_str = "output/epoch_phy"
area_names = c("R","K","O","M","H","Z")
plot_scale = 10/17.4

source("scripts/plot_anc_range.R")
