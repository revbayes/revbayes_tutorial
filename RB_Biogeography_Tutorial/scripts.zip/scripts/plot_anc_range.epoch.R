out_str = "output/epoch"
area_names = c("K","O","M","H")
plot_scale = 5/15

source("scripts/plot_anc_range.R")
