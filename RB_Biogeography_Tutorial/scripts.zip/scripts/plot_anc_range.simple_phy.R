out_str = "output/simple_phy"
area_names = c("R","K","O","M","H","Z")
plot_scale = 5/5.3

source("scripts/plot_anc_range.R")
