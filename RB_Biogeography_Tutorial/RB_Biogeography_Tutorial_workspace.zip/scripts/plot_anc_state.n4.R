stable = T
if (stable) {
    library(RevGadgets)
} else {
    source("/Users/mlandis/projects/RevGadgets/R/plot_ancestral_states.R")
}
library(ggtree)

out_str = "output/epoch"
#out_str = "output/simple"
tree_fn = paste(out_str, ".ase.tre", sep="")

# area labels
st_lbl = c("K","O","M","H",
           "KO","KM","OM","KH","OH","MH",
           "KOM","KOH","KMH","OMH", 
           "KOMH")

# area colors
st_colors = c(  "#d95f02",
                "#7570b3",
                "#e7298a",
                "#66a61e",
                "#66c2a5",
                "#8da0cb",
                "#e78ac3",
                "#ffd92f",
                "#e5c494",
                "#b3b3b3",
                "#e41a1c",
                "#377eb8",
                "#4daf4a",
                "#984ea3",
                "#ff7f00",
                "#e41a1c")
 

summary_statistic = "MAPRange"
s = 5 / 15
plot_ancestral_states(tree_file=tree_fn,
                      include_start_states=T,
                      shoulder_label_size=1.5,
                      shoulder_label_nudge_x=-0.1*s,
                      summary_statistic=summary_statistic,
                      state_labels=st_lbl,
                      state_colors=st_colors,
                      node_label_size=2,
                      node_size_range=c(2,2),
                      node_label_nudge_x=0.1*s,
                      tip_label_size=2,
                      tip_label_offset=s*0.5,
                      xlim_visible=c(0,s*17),
                      show_posterior_legend=F,
                      show_tree_scale=T)
